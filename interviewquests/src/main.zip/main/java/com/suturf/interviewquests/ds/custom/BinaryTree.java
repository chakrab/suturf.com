package com.suturf.interviewquests.ds.custom;

import java.util.Scanner;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BinaryTree<T> implements Comparable<BinaryTree<T>> {
	
	private static final Logger log = LoggerFactory.getLogger(BinaryTree.class);

	T data;
	BinaryTree<T> leftNode;
	BinaryTree<T> rightNode;
	
	public BinaryTree(T data) {
		
		this.data = data;
		this.leftNode = null;
		this.rightNode = null;
	}
	
	public void insert(final BinaryTree<T> value) {

		if (value.compareTo(this) < 1) {
			if (this.leftNode != null) {
				this.leftNode.insert(value);
			} else {
				this.leftNode = value;
			}
		} else {
			if (this.rightNode != null) {
				this.rightNode.insert(value);
			} else {
				this.rightNode = value;
			}
		}
	}
	
	public void inOrder() {
		if (this.leftNode != null) this.leftNode.inOrder();
		log.info(" > " + this.data);
		if (this.rightNode != null) this.rightNode.inOrder();
	}
	
	public void preOrder() {
		log.info(" > " + this.data);
		if (this.leftNode != null) this.leftNode.inOrder();
		if (this.rightNode != null) this.rightNode.inOrder();
	}
	
	public void postOrder() {
		if (this.leftNode != null) this.leftNode.inOrder();
		if (this.rightNode != null) this.rightNode.inOrder();
		log.info(" > " + this.data);
	}
	
	public void visualizeTree(final StringBuilder sb, final String seps) {
		
		sb.append(seps);
		sb.append("|---");
		sb.append(this.data);
		sb.append("\n");
		
		if (this.leftNode != null) this.leftNode.visualizeTree(sb, seps + "|    ");
		if (this.rightNode != null) this.rightNode.visualizeTree(sb, seps + "|    ");
	}

	@Override
	public int compareTo(BinaryTree<T> binaryTree) {

		if (binaryTree.data instanceof Integer) {
			int d1 = Integer.parseInt(binaryTree.data.toString());
			int d2 = Integer.parseInt(this.data.toString());
			return (d1 > d2 ? -1 : 1); 
		}
		
		return 1;
	}
	
	public static void main(final String[] args) {
		System.out.println("Provide numbers:");
		final Scanner scan = new Scanner(System.in);
		String s = scan.nextLine();
		if ("".equals(s)) {
			s = "12, 45, 11, 67, 42, 8, 1, 89, 34, 22, 65, 80, 52";
		}
		scan.close();

		final String [] parts = s.split(",");
		final BinaryTree<Integer> root = new BinaryTree<>(Integer.parseInt(parts[0].trim()));
		for (int i=1; i<parts.length; i++) {
			final BinaryTree<Integer> bt = new BinaryTree<>(Integer.parseInt(parts[i].trim()));
			root.insert(bt);
		}
		
		log.info("In Order -->");
		root.inOrder();
		
		log.info("Pre Order -->");
		root.preOrder();
		
		log.info("Post Order -->");
		root.postOrder();
		
		final StringBuilder sb = new StringBuilder();
		root.visualizeTree(sb, "");
		System.out.println("\n");
		System.out.println(sb);
	}
}
